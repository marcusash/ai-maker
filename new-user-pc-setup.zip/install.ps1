#Requires -Version 5.1
<#
.SYNOPSIS
    new-user-pc-setup v1.0 — Unified PC setup for AI agent workspaces.
.DESCRIPTION
    One-script installer for a new Windows machine. Installs dev tools,
    authenticates GitHub, auto-detects existing workspace (restore vs fresh),
    scaffolds AI Maker + optional AI Workbench, and configures terminal.

    ENTRY POINT: Double-click setup.bat (handles pwsh bootstrapping).
.NOTES
    Works with Windows PowerShell 5.1 for bootstrap; installs PS7 for main work.
    All tools resolved by absolute path after install — never relies on PATH.
#>

[CmdletBinding()]
param(
    [ValidateSet("Blue", "Red")]
    [string]$Tier = "Blue",
    [switch]$SkipGitHub,
    [switch]$SkipAgency,
    [string]$WorkspacePath = "C:\GitHub\ai-workspace",
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"
$script:Failures = @()
$script:LogLines = @()
$script:StartTime = Get-Date

# ═══════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════

function Write-Step {
    param([string]$Message)
    $ts = (Get-Date).ToString("HH:mm:ss")
    Write-Host "  [$ts] $Message" -ForegroundColor Cyan
    $script:LogLines += "[$ts] STEP: $Message"
}

function Write-OK {
    param([string]$Message)
    Write-Host "  ✓ $Message" -ForegroundColor Green
    $script:LogLines += "  OK: $Message"
}

function Write-Warn {
    param([string]$Message)
    Write-Host "  ⚠ $Message" -ForegroundColor Yellow
    $script:LogLines += "  WARN: $Message"
}

function Write-Fail {
    param([string]$Message, [string]$Remediation)
    Write-Host "  ✗ $Message" -ForegroundColor Red
    if ($Remediation) { Write-Host "    → $Remediation" -ForegroundColor Gray }
    $script:Failures += $Message
    $script:LogLines += "  FAIL: $Message"
}

function Refresh-Path {
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
                [System.Environment]::GetEnvironmentVariable("Path", "User")
}

function Resolve-Exe {
    param([string]$Name, [string[]]$KnownPaths)
    # Try PATH first
    $found = Get-Command $Name -ErrorAction SilentlyContinue
    if ($found) { return $found.Source }
    # Try known install locations
    foreach ($p in $KnownPaths) {
        $expanded = [System.Environment]::ExpandEnvironmentVariables($p)
        if (Test-Path $expanded) { return $expanded }
    }
    return $null
}

function Install-WingetPackage {
    param([string]$Id, [string]$DisplayName, [string[]]$KnownPaths, [switch]$Required)

    Write-Host "  $DisplayName... " -NoNewline -ForegroundColor Gray

    # Check if already installed
    $exe = Resolve-Exe -Name ($KnownPaths | Split-Path -Leaf | Select-Object -First 1) -KnownPaths $KnownPaths
    if (-not $exe) {
        # Also check winget list
        $check = winget list --id $Id --accept-source-agreements 2>&1 | Out-String
        if ($check -match [regex]::Escape($Id)) {
            Refresh-Path
            $exe = Resolve-Exe -Name ($DisplayName.ToLower()) -KnownPaths $KnownPaths
        }
    }

    if ($exe) {
        Write-Host "already installed" -ForegroundColor Green
        $script:LogLines += "  SKIP: $DisplayName already at $exe"
        return $exe
    }

    if ($WhatIf) {
        Write-Host "would install" -ForegroundColor Yellow
        return "DRYRUN"
    }

    # Install
    $result = winget install --id $Id --source winget --accept-source-agreements --accept-package-agreements 2>&1 | Out-String
    $script:LogLines += "  WINGET: $Id exit=$LASTEXITCODE"

    Refresh-Path
    $exe = Resolve-Exe -Name ($KnownPaths | Split-Path -Leaf | Select-Object -First 1) -KnownPaths $KnownPaths

    if ($exe) {
        Write-Host "installed" -ForegroundColor Green
        return $exe
    } else {
        if ($Required) {
            Write-Fail "$DisplayName install failed" "Run: winget install --id $Id --source winget"
            throw "$DisplayName is required but could not be installed"
        } else {
            Write-Fail "$DisplayName install failed (optional)" "Run: winget install --id $Id --source winget"
            return $null
        }
    }
}

function Save-Log {
    $logDir = Join-Path $env:LOCALAPPDATA "new-user-pc-setup\logs"
    New-Item -ItemType Directory -Path $logDir -Force -ErrorAction SilentlyContinue | Out-Null
    $logFile = Join-Path $logDir "setup-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
    $script:LogLines | Set-Content -Path $logFile -Encoding UTF8
    return $logFile
}

# ═══════════════════════════════════════════════════════════════
# BANNER
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║       new-user-pc-setup v1.0             ║" -ForegroundColor Cyan
Write-Host "  ╚══════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

$tierColor = if ($Tier -eq "Blue") { "Blue" } else { "Red" }
$tierFg = if ($Tier -eq "Blue") { "Cyan" } else { "Red" }
Write-Host "  Tier: $tierColor Pill" -ForegroundColor $tierFg
Write-Host ""

if ($WhatIf) {
    Write-Host "  DRY RUN MODE — no changes will be made" -ForegroundColor Yellow
    Write-Host ""
}


Write-Host ""

# ═══════════════════════════════════════════════════════════════
# MILESTONE 1: BOOTSTRAP & AUTH
# ═══════════════════════════════════════════════════════════════

Write-Step "Installing core tools"

# ─── Git ─────────────────────────────────────────────────────
$GIT_EXE = Install-WingetPackage `
    -Id "Git.Git" `
    -DisplayName "Git" `
    -KnownPaths @(
        "$env:ProgramFiles\Git\cmd\git.exe",
        "${env:ProgramFiles(x86)}\Git\cmd\git.exe"
    ) `
    -Required

# ─── GitHub CLI ──────────────────────────────────────────────
$GH_EXE = Install-WingetPackage `
    -Id "GitHub.cli" `
    -DisplayName "GitHub CLI" `
    -KnownPaths @(
        "$env:ProgramFiles\GitHub CLI\gh.exe",
        "${env:ProgramFiles(x86)}\GitHub CLI\gh.exe",
        "$env:LOCALAPPDATA\GitHub CLI\gh.exe"
    ) `
    -Required

Write-Host ""
Write-Step "Authenticating with GitHub"

# ─── GitHub Auth ─────────────────────────────────────────────
if ($SkipGitHub) {
    Write-Warn "GitHub auth skipped (-SkipGitHub). Workspace setup will be skipped."
    Write-Host ""
} else {
    # Check if already authenticated
    $ghAuth = & $GH_EXE auth status 2>&1 | Out-String
    if ($ghAuth -match "Logged in") {
        Write-OK "Already authenticated with GitHub"
    } else {
        Write-Host "  A browser window will open. Sign in with your GitHub account." -ForegroundColor Gray
        & $GH_EXE auth login --web --git-protocol https
        Write-Host ""
    }

    # Validate identity — must resolve to a real username
    $ghUser = & $GH_EXE api user --jq .login 2>$null
    if (-not $ghUser -or $ghUser -eq "unknown" -or $ghUser -eq "null") {
        Write-Warn "Auth token invalid — re-authenticating..."
        & $GH_EXE auth login --web --git-protocol https
        $ghUser = & $GH_EXE api user --jq .login 2>$null
        if (-not $ghUser -or $ghUser -eq "unknown" -or $ghUser -eq "null") {
            Write-Fail "GitHub authentication failed — could not resolve username" "Run: gh auth login --web"
            throw "GitHub authentication failed"
        }
    }
    Write-OK "Authenticated as: $ghUser"
    $script:LogLines += "  AUTH: user=$ghUser"

    # Enable git credential helper for HTTPS operations
    & $GH_EXE auth setup-git 2>$null

    # ─── User Config (name/email) ────────────────────────────
    Write-Host ""
    Write-Step "Confirming your identity"

    $ghName = & $GH_EXE api user --jq .name 2>$null
    $ghEmail = & $GH_EXE api user --jq .email 2>$null

    # Handle private/missing email
    if (-not $ghEmail -or $ghEmail -eq "null") {
        $ghEmail = "$ghUser@users.noreply.github.com"
    }
    # Handle missing name
    if (-not $ghName -or $ghName -eq "null") {
        $ghName = $ghUser
    }

    # Check existing git config
    $existingName = git config --global user.name 2>$null
    $existingEmail = git config --global user.email 2>$null

    if ($existingName -and $existingEmail) {
        Write-Host "  Git config: $existingName <$existingEmail>" -ForegroundColor White
        if ($existingName -ne $ghName -or $existingEmail -ne $ghEmail) {
            Write-Host "  GitHub profile: $ghName <$ghEmail>" -ForegroundColor DarkGray
            $update = Read-Host "  Update git config to match GitHub? (type 'yes' to update)"
            if ($update -match '^y') {
                if (-not $WhatIf) {
                    git config --global user.name $ghName
                    git config --global user.email $ghEmail
                }
                Write-OK "Git config updated"
            } else {
                Write-OK "Keeping existing git config"
            }
        } else {
            Write-OK "Git config matches GitHub profile"
        }
    } else {
        # No existing config — set from GitHub, confirm with Enter
        Write-Host ""
        Write-Host "  Installing as $ghName ($ghEmail)" -ForegroundColor White
        $override = Read-Host "  Press Enter to confirm, or type a different email"
        if ($override) { $ghEmail = $override }
        if (-not $WhatIf) {
            git config --global user.name $ghName
            git config --global user.email $ghEmail
        }
        Write-OK "Git configured: $ghName <$ghEmail>"
    }

    git config --global init.defaultBranch main 2>$null
}

# ═══════════════════════════════════════════════════════════════
# MILESTONE 1 COMPLETE
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "  ✓ Milestone 1 complete: Bootstrap & Auth" -ForegroundColor Green
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host ""

if ($script:Failures.Count -gt 0) {
    Write-Host "  FAILURES:" -ForegroundColor Red
    foreach ($f in $script:Failures) { Write-Host "    ✗ $f" -ForegroundColor Red }
    $logFile = Save-Log
    Write-Host "  Log saved: $logFile" -ForegroundColor DarkGray
    Write-Host "  Fix the issues above and re-run setup.bat" -ForegroundColor Yellow
    Read-Host "  Press Enter to exit"
    exit 1
}

# ═══════════════════════════════════════════════════════════════
# MILESTONE 2: AUTO-DETECT & BRANCHING
# ═══════════════════════════════════════════════════════════════

# ─── Detect old CLI workspace folders ────────────────────────
$oldPaths = @("C:\AIMaker", "C:\AIWorkbench") | Where-Object { Test-Path $_ }
if ($oldPaths) {
    Write-Host ""
    Write-Warn "Found old workspace folders from a previous installer:"
    foreach ($op in $oldPaths) { Write-Host "    $op" -ForegroundColor DarkGray }
    $cleanup = Read-Host "  Remove them? (type 'yes' to delete, Enter to skip)"
    if ($cleanup -match '^y') {
        foreach ($op in $oldPaths) {
            Remove-Item $op -Recurse -Force -ErrorAction SilentlyContinue
            Write-OK "Removed $op"
        }
    } else {
        Write-Host "  Keeping old folders (you can remove them manually later)" -ForegroundColor Gray
    }
}

if ($SkipGitHub) {
    Write-Step "Skipping workspace detection (-SkipGitHub)"
    $script:SetupPath = "skip"
} else {
    Write-Step "Detecting existing workspace"

    # ─── Check remote: does ai-workspace repo exist on GitHub? ───
    $repoName = "ai-workspace"
    $remoteCheck = & $GH_EXE repo view "$ghUser/$repoName" --json name,owner 2>&1 | Out-String

    $script:SetupPath = $null
    $script:RemoteRepoExists = $false
    $script:LocalFolderState = "missing"  # missing | clean | dirty | wrong-remote | broken | not-git

    if ($LASTEXITCODE -eq 0) {
        # Repo found — validate owner
        try {
            $repoInfo = $remoteCheck | ConvertFrom-Json
            $repoOwner = $repoInfo.owner.login
            if ($repoOwner -ne $ghUser) {
                Write-Warn "Found ai-workspace but owned by '$repoOwner', not '$ghUser'"
                Write-Host "  This may be an org repo. Treating as fresh install." -ForegroundColor Gray
                $script:SetupPath = "fresh"
            } else {
                $script:RemoteRepoExists = $true
                Write-OK "Found your ai-workspace repo on GitHub"
            }
        } catch {
            Write-Warn "Could not parse repo info — treating as fresh"
            $script:SetupPath = "fresh"
        }
    } else {
        # Distinguish "not found" from "network error"
        if ($remoteCheck -match "Could not resolve|timeout|connection refused|TLS|SSL") {
            Write-Fail "Cannot reach GitHub API" "Check VPN/proxy and retry"
            $logFile = Save-Log
            Write-Host "  Log saved: $logFile" -ForegroundColor DarkGray
            Read-Host "  Press Enter to exit"
            exit 1
        } else {
            # 404 — repo doesn't exist
            Write-Host "  No existing ai-workspace repo found" -ForegroundColor Gray
            $script:SetupPath = "fresh"
        }
    }

    # ─── Check local: what's at the workspace path? ──────────────
    if ($script:RemoteRepoExists -and -not $script:SetupPath) {
        Write-Host ""
        Write-Step "Checking local workspace: $WorkspacePath"

        if (-not (Test-Path $WorkspacePath)) {
            $script:LocalFolderState = "missing"
            Write-Host "  Not on this PC yet (will download from GitHub)" -ForegroundColor Gray
            $script:SetupPath = "restore"
        }
        elseif (-not (Test-Path (Join-Path $WorkspacePath ".git"))) {
            $script:LocalFolderState = "not-git"
            Write-Warn "$WorkspacePath exists but isn't a git repo — removing and re-downloading"
            Remove-Item -Recurse -Force $WorkspacePath -ErrorAction SilentlyContinue
            $script:LocalFolderState = "missing"
            $script:SetupPath = "restore"
        }
        else {
            # It's a git repo — check if it's the right one
            $currentRemote = git -C $WorkspacePath remote get-url origin 2>$null
            if ($currentRemote -match "$ghUser/$repoName") {
                # Correct repo — check for uncommitted changes
                $status = git -C $WorkspacePath status --porcelain 2>$null
                if ($status) {
                    $script:LocalFolderState = "dirty"
                    Write-Warn "Workspace has uncommitted changes"
                    Write-Host "  Will pull latest but won't overwrite your changes." -ForegroundColor Gray
                    $script:SetupPath = "restore"
                } else {
                    $script:LocalFolderState = "clean"
                    Write-OK "Workspace exists and is clean"
                    $script:SetupPath = "restore"
                }
            }
            elseif (-not $currentRemote) {
                # No remote — likely a broken clone
                $script:LocalFolderState = "broken"
                Write-Warn "Folder exists but setup was never completed"
                $confirm = Read-Host "  Delete and re-download? (type 'yes' to delete)"
                if ($confirm -match '^y') {
                    Remove-Item -Recurse -Force $WorkspacePath
                    Write-OK "Removed incomplete folder"
                    $script:LocalFolderState = "missing"
                    $script:SetupPath = "restore"
                } else {
                    Write-Host "  Skipping workspace restore." -ForegroundColor Yellow
                    $script:SetupPath = "fresh"
                }
            }
            else {
                $script:LocalFolderState = "wrong-remote"
                Write-Warn "Folder is linked to a different project: $currentRemote"
                Write-Host "  Cannot overwrite someone else's workspace. Remove or rename it first." -ForegroundColor Yellow
                Write-Fail "Folder belongs to a different project" "Remove $WorkspacePath and re-run"
                $logFile = Save-Log
                Read-Host "  Press Enter to exit"
                exit 1
            }
        }
    }

    # Default to fresh if not set
    if (-not $script:SetupPath) { $script:SetupPath = "fresh" }

    # ─── Confirm with user ───────────────────────────────────────
    Write-Host ""
    Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray

    if ($script:SetupPath -eq "restore") {
        Write-Host "  RESTORE PATH — Download your existing workspace to this PC" -ForegroundColor Green
        Write-Host "  Your AI workspace will be saved to: $WorkspacePath" -ForegroundColor Gray
        Write-Host ""
        $confirm = Read-Host "  Press Enter to continue, or type 'no' to cancel"
        if ($confirm -match '^n') {
            Write-Host "  Switching to fresh setup instead." -ForegroundColor Yellow
            $script:SetupPath = "fresh"
        }
    }

    if ($script:SetupPath -eq "fresh") {
        Write-Host "  FRESH PATH — Create new AI workspace from scratch" -ForegroundColor Cyan
        Write-Host "  A private repo '$ghUser/$repoName' will be created on GitHub" -ForegroundColor Gray
        Write-Host ""
        $confirm = Read-Host "  Press Enter to continue, or type 'no' to cancel"
        if ($confirm -match '^n') {
            Write-Host "  Setup cancelled." -ForegroundColor Yellow
            $logFile = Save-Log
            exit 0
        }
    }

    Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
}

# ═══════════════════════════════════════════════════════════════
# MILESTONE 2 COMPLETE
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "  ✓ Milestone 2 complete: Auto-Detect" -ForegroundColor Green
Write-Host "  Setup path: $($script:SetupPath.ToUpper())" -ForegroundColor White
Write-Host "  Local state: $($script:LocalFolderState)" -ForegroundColor White
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host ""

# ═══════════════════════════════════════════════════════════════
# MILESTONE 3: APP INSTALLATION
# ═══════════════════════════════════════════════════════════════

Write-Step "Installing apps"

# Apps to install via winget (Git and gh already done in M1)
$apps = @(
    @{
        Id = "Microsoft.PowerShell"
        Name = "PowerShell 7"
        KnownPaths = @(
            "$env:ProgramFiles\PowerShell\7\pwsh.exe",
            "$env:LOCALAPPDATA\Microsoft\PowerShell\pwsh.exe"
        )
        Required = $true
    },
    @{
        Id = "GitHub.CopilotApp"
        Name = "GitHub Copilot"
        KnownPaths = @(
            "$env:LOCALAPPDATA\Programs\GitHub Copilot\github.exe"
        )
        Required = $true
    },
    @{
        Id = "Microsoft.VisualStudioCode"
        Name = "VS Code"
        KnownPaths = @(
            "$env:LOCALAPPDATA\Programs\Microsoft VS Code\bin\code.cmd",
            "$env:ProgramFiles\Microsoft VS Code\bin\code.cmd"
        )
        Required = $false
    },
    @{
        Id = "OpenJS.NodeJS.LTS"
        Name = "Node.js"
        KnownPaths = @(
            "$env:ProgramFiles\nodejs\node.exe"
        )
        Required = $false
    },
    @{
        Id = "JanDeDobbeleer.OhMyPosh"
        Name = "Oh My Posh"
        KnownPaths = @(
            "$env:LOCALAPPDATA\Programs\oh-my-posh\bin\oh-my-posh.exe"
        )
        Required = $false
    },
    @{
        Id = "Microsoft.WindowsTerminal"
        Name = "Windows Terminal"
        KnownPaths = @(
            "$env:LOCALAPPDATA\Microsoft\WindowsApps\wt.exe"
        )
        Required = $false
    }
)

$script:InstalledApps = @{}

foreach ($app in $apps) {
    $result = Install-WingetPackage -Id $app.Id -DisplayName $app.Name -KnownPaths $app.KnownPaths -Required:$app.Required
    $script:InstalledApps[$app.Name] = $result
}

# ─── Agency (DISABLED — pending fix from Agency team) ────────
# Agency's runtime crashes with HTTP 401 against agency-microsoft/.github-private
# when tokens lack org access. Skipping install until the team ships a fix.
# To enable later: remove this comment block, restore the install logic.
Write-Host ""
Write-Host "  Agency... " -NoNewline -ForegroundColor Gray
Write-Host "skipped (temporarily disabled)" -ForegroundColor DarkGray
$script:InstalledApps["Agency"] = "DISABLED"

# ─── WorkIQ plugin for Copilot App ───────────────────────────
Write-Host ""
Write-Host "  WorkIQ plugin... " -NoNewline -ForegroundColor Gray

# Find copilot CLI — may not be on PATH on fresh machines
$copilotExe = (Get-Command copilot -ErrorAction SilentlyContinue).Source
if (-not $copilotExe) {
    # Trigger gh to download copilot CLI
    gh copilot --version 2>&1 | Out-Null
    # Check known download locations
    $knownPaths = @(
        "$env:LOCALAPPDATA\GitHub CLI\copilot\copilot.exe",
        "$env:LOCALAPPDATA\GitHub\Copilot\copilot.exe",
        "$env:LOCALAPPDATA\Programs\GitHub Copilot\resources\app\node_modules\.bin\copilot.cmd"
    )
    foreach ($p in $knownPaths) {
        if (Test-Path $p) { $copilotExe = $p; break }
    }
}
if (-not $copilotExe) {
    # Last resort: refresh PATH and retry
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
    $copilotExe = (Get-Command copilot -ErrorAction SilentlyContinue).Source
}

if ($copilotExe) {
    $installed = & $copilotExe plugin list 2>&1 | Select-String "workiq"
    if ($installed) {
        Write-Host "already installed" -ForegroundColor Green
        $script:InstalledApps["WorkIQ"] = "installed"
    } else {
        & $copilotExe plugin install workiq@copilot-plugins 2>&1 | Out-Null
        $verify = & $copilotExe plugin list 2>&1 | Select-String "workiq"
        if ($verify) {
            Write-Host "installed" -ForegroundColor Green
            $script:InstalledApps["WorkIQ"] = "installed"
        } else {
            Write-Host "failed (run: copilot plugin install workiq@copilot-plugins)" -ForegroundColor Yellow
            $script:InstalledApps["WorkIQ"] = "FAILED"
        }
    }
} else {
    Write-Host "skipped (copilot CLI not found)" -ForegroundColor DarkGray
    $script:InstalledApps["WorkIQ"] = "SKIPPED"
}

# ─── Pre-trust workspace folder for Copilot CLI ─────────────
$copilotConfig = Join-Path $env:USERPROFILE ".copilot\config.json"
if (Test-Path $copilotConfig) {
    $cfg = Get-Content $copilotConfig -Raw | ConvertFrom-Json
    if (-not $cfg.trustedFolders) { $cfg | Add-Member -NotePropertyName trustedFolders -NotePropertyValue @() }
    if ($cfg.trustedFolders -notcontains $WorkspacePath) {
        $cfg.trustedFolders += $WorkspacePath
        $cfg | ConvertTo-Json -Depth 10 | Set-Content $copilotConfig -Force
    }
}

# ─── Nerd Font for terminal glyphs ──────────────────────────
Write-Host ""
Write-Step "Installing terminal font"

$fontName = "CaskaydiaCoveNerdFont-Regular.ttf"
$fontDir = "$env:LOCALAPPDATA\Microsoft\Windows\Fonts"
$fontPath = Join-Path $fontDir $fontName

Write-Host "  Caskaydia Cove Nerd Font... " -NoNewline -ForegroundColor Gray
if (Test-Path $fontPath) {
    Write-Host "already installed" -ForegroundColor Green
} elseif ($WhatIf) {
    Write-Host "would install" -ForegroundColor Yellow
} else {
    try {
        $omp = Resolve-Exe -Name "oh-my-posh" -KnownPaths @("$env:LOCALAPPDATA\Programs\oh-my-posh\bin\oh-my-posh.exe")
        if ($omp) {
            & $omp font install CascadiaCode 2>&1 | Out-Null
            if (Test-Path $fontPath) {
                Write-Host "installed" -ForegroundColor Green
            } else {
                # Font might install to a different exact filename
                $anyNerd = Get-ChildItem $fontDir -Filter "*CaskaydiaCove*" -ErrorAction SilentlyContinue
                if ($anyNerd) {
                    Write-Host "installed" -ForegroundColor Green
                } else {
                    Write-Warn "Font install may not have completed — check terminal settings"
                }
            }
        } else {
            Write-Warn "Oh My Posh not found — skipping font install"
        }
    } catch {
        Write-Warn "Font install failed (cosmetic only)"
    }
}

# ═══════════════════════════════════════════════════════════════
# MILESTONE 3 COMPLETE
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "  ✓ Milestone 3 complete: App Installation" -ForegroundColor Green
Write-Host ""
Write-Host "  Installed:" -ForegroundColor White
foreach ($key in $script:InstalledApps.Keys | Sort-Object) {
    $val = $script:InstalledApps[$key]
    if ($val -and $val -ne "DRYRUN") {
        Write-Host "    ✓ $key" -ForegroundColor Green
    } elseif ($val -eq "DRYRUN") {
        Write-Host "    ~ $key (dry run)" -ForegroundColor Yellow
    } else {
        Write-Host "    ✗ $key (failed)" -ForegroundColor Red
    }
}
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host ""

# ═══════════════════════════════════════════════════════════════
# MILESTONE 4/5: WORKSPACE SETUP (FRESH or RESTORE)
# ═══════════════════════════════════════════════════════════════

if ($script:SetupPath -eq "restore") {
    # ─── MILESTONE 5: RESTORE PATH ──────────────────────────────
    Write-Step "Setting up workspace (restore)"

    if ($script:LocalFolderState -eq "missing") {
        # Clone the repo
        Write-Host "  Downloading your workspace from GitHub..." -ForegroundColor Gray
        $parentDir = Split-Path $WorkspacePath -Parent
        if (-not (Test-Path $parentDir)) {
            New-Item -ItemType Directory -Path $parentDir -Force | Out-Null
        }

        if ($WhatIf) {
            Write-Host "  Would clone $ghUser/ai-workspace to $WorkspacePath" -ForegroundColor Yellow
        } else {
            $cloneResult = & $GH_EXE repo clone "$ghUser/ai-workspace" $WorkspacePath 2>&1 | Out-String
            if ($LASTEXITCODE -ne 0) {
                # Retry once — sometimes first attempt fails on fresh auth
                Start-Sleep -Seconds 2
                $cloneResult = & $GH_EXE repo clone "$ghUser/ai-workspace" $WorkspacePath 2>&1 | Out-String
            }

            if ($LASTEXITCODE -ne 0) {
                Write-Fail "Could not download workspace" "Run: gh repo clone $ghUser/ai-workspace $WorkspacePath"
                $script:LogLines += "  CLONE FAILED: $cloneResult"
            } elseif (Test-Path (Join-Path $WorkspacePath ".git")) {
                Write-OK "Workspace downloaded to $WorkspacePath"
            } else {
                Write-Fail "Download appeared to succeed but folder is incomplete" "Try: gh repo clone $ghUser/ai-workspace $WorkspacePath"
            }
        }
    }
    elseif ($script:LocalFolderState -eq "clean") {
        # Pull latest
        Write-Host "  Updating workspace with latest changes..." -ForegroundColor Gray
        if ($WhatIf) {
            Write-Host "  Would pull latest in $WorkspacePath" -ForegroundColor Yellow
        } else {
            $pullResult = git -C $WorkspacePath pull --ff-only 2>&1 | Out-String
            if ($LASTEXITCODE -eq 0) {
                Write-OK "Workspace updated"
            } else {
                Write-Warn "Could not update workspace (you may need to sync manually)"
                $script:LogLines += "  PULL FAILED: $pullResult"
            }
        }
    }
    elseif ($script:LocalFolderState -eq "dirty") {
        # Don't touch it — just confirm it exists
        Write-Host "  Workspace has your uncommitted changes — leaving as-is" -ForegroundColor Gray
        Write-OK "Workspace ready at $WorkspacePath (has local changes)"
    }

    # Verify workspace is usable
    if (Test-Path (Join-Path $WorkspacePath ".git")) {
        Write-Host ""
        Write-OK "Workspace ready: $WorkspacePath"
    }

} elseif ($script:SetupPath -eq "fresh") {
    # ─── MILESTONE 4: FRESH PATH ────────────────────────────────
    Write-Step "Setting up workspace (new)"

    $repoName = "ai-workspace"

    # Create the repo on GitHub
    Write-Host "  Creating your AI workspace on GitHub..." -ForegroundColor Gray
    if ($WhatIf) {
        Write-Host "  Would create private repo $ghUser/$repoName" -ForegroundColor Yellow
    } else {
        # Check if repo somehow already exists (race condition / retry)
        $exists = & $GH_EXE repo view "$ghUser/$repoName" --json name 2>&1 | Out-String
        if ($LASTEXITCODE -eq 0) {
            Write-Warn "Repo $ghUser/$repoName already exists on GitHub — will clone it"
            $script:SetupPath = "restore"
            $script:LocalFolderState = "missing"
        } else {
            $createResult = & $GH_EXE repo create $repoName --private --description "AI workspace — skills, vault, and agent configuration" 2>&1 | Out-String
            if ($LASTEXITCODE -ne 0) {
                Write-Fail "Could not create repo on GitHub" "Run: gh repo create $repoName --private"
                $script:LogLines += "  REPO CREATE FAILED: $createResult"
            } else {
                Write-OK "Created private repo: $ghUser/$repoName"
            }
        }
    }

    # Clone the (empty or existing) repo
    if (-not (Test-Path $WorkspacePath)) {
        $parentDir = Split-Path $WorkspacePath -Parent
        if (-not (Test-Path $parentDir)) {
            New-Item -ItemType Directory -Path $parentDir -Force | Out-Null
        }

        Write-Host "  Downloading workspace to this PC..." -ForegroundColor Gray
        if (-not $WhatIf) {
            & $GH_EXE repo clone "$ghUser/$repoName" $WorkspacePath 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $WorkspacePath ".git"))) {
                Write-Fail "Clone failed" "Run: gh repo clone $ghUser/$repoName $WorkspacePath"
            } else {
                Write-OK "Workspace created at $WorkspacePath"
            }
        }
    }

    # Scaffold the workspace structure
    if (Test-Path $WorkspacePath) {
        Write-Host ""
        Write-Step "Scaffolding workspace files"

        $dirs = @(
            ".github",
            ".github/skills",
            ".github/plugins",
            "vault",
            "vault/how-to",
            "vault/proposals",
            "vault/references",
            "vault/decisions",
            "docs",
            "canvas",
            "logs"
        )

        foreach ($dir in $dirs) {
            $fullPath = Join-Path $WorkspacePath $dir
            if (-not (Test-Path $fullPath)) {
                New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
            }
        }

        # copilot-instructions.md
        $instructionsPath = Join-Path $WorkspacePath ".github\copilot-instructions.md"
        if (-not (Test-Path $instructionsPath)) {
            @"
# AI Maker

You are **AI Maker** — a creative strategist and executive thinking partner.

## Identity

- **Name:** AI Maker
- **Role:** Strategic thinking partner for managers and leaders
- **Tone:** Clear, confident, concise. Lead with the answer, then support with evidence.

When asked "who are you", identify as AI Maker.

## What you help with

- Research and competitive analysis
- Brainstorming and red-teaming
- Design thinking and UX strategy
- Data interpretation and metrics
- Communication drafts and planning
- Knowledge management and vault recall
- Microsoft 365 workflows via WorkIQ

## Working style

1. Start with the user's goal and deliver a concrete answer.
2. Be direct and scannable.
3. Flag uncertainty clearly.
4. Save durable decisions when asked.
"@ | Set-Content -Path $instructionsPath -Encoding UTF8
        }

        # .gitignore
        $gitignorePath = Join-Path $WorkspacePath ".gitignore"
        if (-not (Test-Path $gitignorePath)) {
            @"
# Logs
logs/*.log

# OS
.DS_Store
Thumbs.db

# Editor
.vscode/settings.json
"@ | Set-Content -Path $gitignorePath -Encoding UTF8
        }

        # .ai-maker-bootstrapped marker
        $markerPath = Join-Path $WorkspacePath ".ai-maker-bootstrapped"
        if (-not (Test-Path $markerPath)) {
            "bootstrapped=$(Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')" | Set-Content -Path $markerPath -Encoding UTF8
        }

        # Initial commit and push
        Write-Host "  Saving workspace to GitHub..." -ForegroundColor Gray
        if (-not $WhatIf) {
            Push-Location $WorkspacePath
            git add -A 2>&1 | Out-Null
            $hasChanges = git status --porcelain 2>$null
            if ($hasChanges) {
                git commit -m "Initial workspace setup" 2>&1 | Out-Null
                git push origin main 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) {
                    Write-OK "Workspace pushed to GitHub"
                } else {
                    Write-Warn "Push failed — you can push manually later with: git push"
                }
            } else {
                Write-Host "  No changes to push" -ForegroundColor Gray
            }
            Pop-Location
        }

        Write-OK "Workspace scaffolded with starter files"
    }
}

# ─── Install Skills & Agents into Workspace (fresh only) ─────
if ($script:SetupPath -eq "fresh" -and (Test-Path $WorkspacePath)) {
    Write-Host ""
    Write-Step "Installing skills & agent definitions"

    $skillsSource = Join-Path $PSScriptRoot "skills"
    $skillsDest = Join-Path $WorkspacePath ".github\skills"

    if (Test-Path $skillsSource) {
        # Determine which skills to install based on tier
        $makerSkills = Get-ChildItem $skillsSource -Directory | Where-Object { $_.Name -like "ai-maker-*" }
        $workbenchSkills = Get-ChildItem $skillsSource -Directory | Where-Object { $_.Name -like "ai-workbench-*" }

        $skillsToInstall = if ($Tier -eq "Blue") { $makerSkills } else { $makerSkills + $workbenchSkills }

        $installed = 0
        foreach ($skill in $skillsToInstall) {
            $destDir = Join-Path $skillsDest $skill.Name
            if (-not (Test-Path $destDir)) {
                New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            }
            # Copy SKILL.md (and any other files in the skill folder)
            Copy-Item -Path (Join-Path $skill.FullName "*") -Destination $destDir -Recurse -Force
            $installed++
        }
        Write-OK "$installed skills installed ($Tier tier)"
    } else {
        Write-Warn "Skills source not found at $skillsSource — skipping skill install"
    }

    # Agent definitions
    $agentsDir = Join-Path $WorkspacePath ".github\agents"
    if (-not (Test-Path $agentsDir)) {
        New-Item -ItemType Directory -Path $agentsDir -Force | Out-Null
    }

    $agentSource = Join-Path $PSScriptRoot "agents"
    if (Test-Path $agentSource) {
        # Always install ai-maker agent
        $makerAgent = Join-Path $agentSource "ai-maker.md"
        if (Test-Path $makerAgent) {
            Copy-Item $makerAgent -Destination $agentsDir -Force
        }
        # Red tier also gets ai-workbench agent
        if ($Tier -eq "Red") {
            $workbenchAgent = Join-Path $agentSource "ai-workbench.md"
            if (Test-Path $workbenchAgent) {
                Copy-Item $workbenchAgent -Destination $agentsDir -Force
            }
        }
        Write-OK "Agent definitions installed"
    } else {
        Write-Warn "Agents source not found at $agentSource — skipping agent install"
    }

    # Commit skills & agents to the workspace repo
    if (-not $WhatIf) {
        Push-Location $WorkspacePath
        git add -A 2>&1 | Out-Null
        $hasChanges = git status --porcelain 2>$null
        if ($hasChanges) {
            $skillCount = if ($Tier -eq "Blue") { "11" } else { "22" }
            git commit -m "Add $skillCount skills + agent definitions ($Tier tier)" 2>&1 | Out-Null
            git push origin main 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) {
                Write-OK "Skills pushed to GitHub"
            } else {
                Write-Warn "Push failed — you can push manually later"
            }
        }
        Pop-Location
    }
}

# ─── Upgrade path: Blue → Red (add Workbench skills to existing workspace) ───
if ($script:SetupPath -eq "restore" -and $Tier -eq "Red" -and (Test-Path $WorkspacePath)) {
    $skillsDest = Join-Path $WorkspacePath ".github\skills"
    $hasWorkbench = Get-ChildItem $skillsDest -Directory -Filter "ai-workbench-*" -ErrorAction SilentlyContinue
    if (-not $hasWorkbench -or $hasWorkbench.Count -eq 0) {
        $skillsSource = Join-Path $PSScriptRoot "skills"
        $workbenchSkills = Get-ChildItem $skillsSource -Directory | Where-Object { $_.Name -like "ai-workbench-*" }
        if ($workbenchSkills) {
            Write-Host ""
            Write-Step "Upgrade detected: adding AI Workbench skills"
            Write-Host "  Your workspace has AI Maker but not AI Workbench." -ForegroundColor Gray
            $upgrade = Read-Host "  Add 11 Workbench skills? (press Enter for yes, type 'no' to skip)"
            if ($upgrade -notmatch '^n') {
                foreach ($skill in $workbenchSkills) {
                    $destDir = Join-Path $skillsDest $skill.Name
                    if (-not (Test-Path $destDir)) {
                        New-Item -ItemType Directory -Path $destDir -Force | Out-Null
                    }
                    Copy-Item -Path (Join-Path $skill.FullName "*") -Destination $destDir -Recurse -Force
                }
                # Add workbench agent definition
                $agentsDir = Join-Path $WorkspacePath ".github\agents"
                $agentSource = Join-Path $PSScriptRoot "agents\ai-workbench.md"
                if ((Test-Path $agentSource) -and (Test-Path $agentsDir)) {
                    Copy-Item $agentSource -Destination $agentsDir -Force
                }
                # Commit upgrade
                if (-not $WhatIf) {
                    Push-Location $WorkspacePath
                    git add -A 2>&1 | Out-Null
                    git commit -m "Upgrade: add 11 AI Workbench skills (Blue → Red)" 2>&1 | Out-Null
                    git push origin main 2>&1 | Out-Null
                    Pop-Location
                }
                Write-OK "11 Workbench skills added to your workspace"
            } else {
                Write-Host "  Skipped — you can add them later by re-running with -Tier Red" -ForegroundColor Gray
            }
        }

        # ─── Ensure latest agent definitions are synced on restore ────────
        if ($script:SetupPath -eq "restore" -and (Test-Path $WorkspacePath)) {
            $agentsDir = Join-Path $WorkspacePath ".github\agents"
            if (-not (Test-Path $agentsDir)) {
                New-Item -ItemType Directory -Path $agentsDir -Force | Out-Null
            }

            $agentSource = Join-Path $PSScriptRoot "agents"
            if (Test-Path $agentSource) {
                $makerAgent = Join-Path $agentSource "ai-maker.md"
                if (Test-Path $makerAgent) {
                    Copy-Item $makerAgent -Destination $agentsDir -Force
                }

                if ($Tier -eq "Red") {
                    $workbenchAgent = Join-Path $agentSource "ai-workbench.md"
                    if (Test-Path $workbenchAgent) {
                        Copy-Item $workbenchAgent -Destination $agentsDir -Force
                    }
                }

                if (-not $WhatIf) {
                    Push-Location $WorkspacePath
                    git add -A 2>&1 | Out-Null
                    $hasChanges = git status --porcelain 2>$null
                    if ($hasChanges) {
                        git commit -m "Sync latest agent definitions from installer" 2>&1 | Out-Null
                        git push origin main 2>&1 | Out-Null
                    }
                    Pop-Location
                }

                Write-OK "Agent definitions synced"
            }
        }
    }
}

# ─── Always sync latest agent definitions on restore ───────────────
if ($script:SetupPath -eq "restore" -and (Test-Path $WorkspacePath)) {
    $agentsDir = Join-Path $WorkspacePath ".github\agents"
    if (-not (Test-Path $agentsDir)) {
        New-Item -ItemType Directory -Path $agentsDir -Force | Out-Null
    }

    $agentSource = Join-Path $PSScriptRoot "agents"
    if (Test-Path $agentSource) {
        $makerAgent = Join-Path $agentSource "ai-maker.md"
        if (Test-Path $makerAgent) {
            Copy-Item $makerAgent -Destination $agentsDir -Force
        }

        if ($Tier -eq "Red") {
            $workbenchAgent = Join-Path $agentSource "ai-workbench.md"
            if (Test-Path $workbenchAgent) {
                Copy-Item $workbenchAgent -Destination $agentsDir -Force
            }
        }

        if (-not $WhatIf) {
            Push-Location $WorkspacePath
            git add -A 2>&1 | Out-Null
            $hasChanges = git status --porcelain 2>$null
            if ($hasChanges) {
                git commit -m "Sync latest agent definitions from installer" 2>&1 | Out-Null
                git push origin main 2>&1 | Out-Null
            }
            Pop-Location
        }

        Write-OK "Agent definitions synced"
    }
}

# ═══════════════════════════════════════════════════════════════
# MILESTONE 4/5 COMPLETE
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "  ✓ Workspace setup complete" -ForegroundColor Green
if (Test-Path $WorkspacePath) {
    Write-Host "  Location: $WorkspacePath" -ForegroundColor White
}
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host ""

# ═══════════════════════════════════════════════════════════════
# MILESTONE 6: MACHINE CONFIGURATION
# ═══════════════════════════════════════════════════════════════

# ─── Helper: Self-healing profile block update ───────────────
function Update-ProfileBlock {
    param([string]$ProfilePath, [string]$Block, [string]$Label)

    $dir = Split-Path -Parent $ProfilePath
    if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }

    if (Test-Path $ProfilePath) {
        $content = Get-Content $ProfilePath -Raw

        # Count existing BEGIN markers
        $beginMatches = [regex]::Matches($content, '# === NEW-USER-PC-SETUP BEGIN ===')

        if ($beginMatches.Count -gt 0) {
            # Nuclear cleanup: remove EVERYTHING from first BEGIN to last END (or end of file)
            # This handles: duplicates, BEGIN-without-END, orphaned blocks
            if ($content -match '# === NEW-USER-PC-SETUP END ===') {
                # Has at least one END — remove from first BEGIN to last END
                $cleaned = $content -replace '(?s)# === NEW-USER-PC-SETUP BEGIN ===.*# === NEW-USER-PC-SETUP END ===', ''
            } else {
                # No END marker at all — remove from first BEGIN to end of file
                $cleaned = $content -replace '(?s)# === NEW-USER-PC-SETUP BEGIN ===.*$', ''
            }

            # Also remove orphaned "# Oh My Posh prompt theme" lines between blocks
            $cleaned = $cleaned -replace '(?m)^\s*# Oh My Posh prompt theme\s*$', ''

            # Trim and write clean block
            $cleaned = $cleaned.TrimEnd()
            if ($cleaned.Length -gt 0) {
                $finalContent = $cleaned + "`n`n" + $Block + "`n"
            } else {
                $finalContent = $Block + "`n"
            }
            Set-Content -Path $ProfilePath -Value $finalContent -Force
            Write-Host "  $Label — cleaned and configured" -ForegroundColor Green
            return
        }
    }

    # No existing block — append
    Add-Content -Path $ProfilePath -Value "`n$Block"
    Write-Host "  $Label — configured" -ForegroundColor Green
}

Write-Step "Configuring shell profiles"

$selectedTheme = "powerlevel10k_rainbow"

$profileBlock = @"
# === NEW-USER-PC-SETUP BEGIN ===
# GitHub Copilot CLI aliases
function ghcs { gh copilot suggest @args }
function ghce { gh copilot explain @args }

# Oh My Posh prompt theme
`$_ompTheme = "$selectedTheme"
`$_ompExe = Get-Command oh-my-posh -ErrorAction SilentlyContinue
if (`$_ompExe) {
    `$_ompThemesPath = & oh-my-posh get shell-themes-path 2>`$null
    if (-not `$_ompThemesPath) { `$_ompThemesPath = `$env:POSH_THEMES_PATH }
    if (`$_ompThemesPath -and (Test-Path "`$_ompThemesPath\`$_ompTheme.omp.json")) {
        oh-my-posh init pwsh --config "`$_ompThemesPath\`$_ompTheme.omp.json" | Invoke-Expression
    }
}
# === NEW-USER-PC-SETUP END ===
"@

$docs = [Environment]::GetFolderPath("MyDocuments")
$profiles = @(
    @{ Path = (Join-Path $docs "PowerShell\Microsoft.PowerShell_profile.ps1"); Label = "PowerShell 7" },
    @{ Path = (Join-Path $docs "WindowsPowerShell\Microsoft.PowerShell_profile.ps1"); Label = "Windows PowerShell" }
)

if ($WhatIf) {
    foreach ($p in $profiles) { Write-Host "  $($p.Label) — would configure" -ForegroundColor Yellow }
} else {
    foreach ($p in $profiles) {
        Update-ProfileBlock -ProfilePath $p.Path -Block $profileBlock -Label $p.Label
    }
}

# ─── Windows Terminal Configuration ──────────────────────────
Write-Host ""
Write-Step "Configuring Windows Terminal"

$wtPaths = @(
    "$env:LOCALAPPDATA\Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json",
    "$env:LOCALAPPDATA\Microsoft\Windows Terminal\settings.json"
)
$wtSettings = $wtPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($wtSettings) {
    try {
        # Backup before editing
        $backupPath = "$wtSettings.bak"
        Copy-Item $wtSettings $backupPath -Force
        $settings = Get-Content $wtSettings -Raw | ConvertFrom-Json

        $psCore = "{574e775e-4f2a-5b96-ac1e-a2962a402336}"

        # Set defaults
        if (-not $settings.profiles.defaults) {
            $settings.profiles | Add-Member -NotePropertyName "defaults" -NotePropertyValue ([PSCustomObject]@{}) -Force
        }
        $settings.profiles.defaults | Add-Member -NotePropertyName "suppressApplicationTitle" -NotePropertyValue $true -Force
        $settings.profiles.defaults | Add-Member -NotePropertyName "bellStyle" -NotePropertyValue "none" -Force

        # Set font for PS Core profile
        $psCoreProfile = $settings.profiles.list | Where-Object { $_.guid -eq $psCore }
        if ($psCoreProfile) {
            $fontObj = [PSCustomObject]@{ face = "CaskaydiaCove Nerd Font" }
            $psCoreProfile | Add-Member -NotePropertyName "font" -NotePropertyValue $fontObj -Force
        }

        # Set PS Core as default profile
        $settings.defaultProfile = $psCore

        # Ctrl+V paste binding (Handy/speech-to-text compatibility)
        $bindingKey = if ($settings.PSObject.Properties["actions"]) { "actions" } else { "keybindings" }
        $existingBindings = $settings.PSObject.Properties[$bindingKey]
        $hasPaste = $false
        if ($existingBindings) {
            $hasPaste = ($settings.$bindingKey | Where-Object { $_.keys -eq "ctrl+v" }).Count -gt 0
        }
        if (-not $hasPaste) {
            $pasteBinding = [PSCustomObject]@{ id = "Terminal.PasteFromClipboard"; keys = "ctrl+v" }
            if (-not $existingBindings -or $settings.$bindingKey.Count -eq 0) {
                $settings | Add-Member -MemberType NoteProperty -Name $bindingKey -Value @($pasteBinding) -Force
            } else {
                $settings.$bindingKey += $pasteBinding
            }
            Write-Host "  Ctrl+V paste binding added" -ForegroundColor Green
        }

        if (-not $WhatIf) {
            $settings | ConvertTo-Json -Depth 10 | Set-Content $wtSettings -Force
        }
        Write-OK "Windows Terminal configured"

        # ─── AI Maker + AI Workbench profiles ────────────────────
        Write-Host ""
        Write-Step "Adding AI agent terminal profiles"

        $aiMakerGuid = "{a1f2e3d4-b5c6-7890-abcd-ef0123456789}"
        $aiWorkbenchGuid = "{b2e3f4a5-c6d7-8901-bcde-f01234567890}"

        # Remove old versions if they exist (to update startingDirectory)
        $settings.profiles.list = @($settings.profiles.list | Where-Object {
            $_.guid -ne $aiMakerGuid -and $_.guid -ne $aiWorkbenchGuid
        })

        # AI maker profile (always) — matches nancie-setup pattern
        $aiMakerProfile = [PSCustomObject]@{
            guid                    = $aiMakerGuid
            name                    = "AI maker"
            commandline             = "pwsh.exe -NoProfile -Command `"gh copilot`""
            tabColor                = "#FFCB05"
            tabTitle                = "AI maker"
            suppressApplicationTitle = $true
            startingDirectory       = $WorkspacePath
            hidden                  = $true
        }
        $settings.profiles.list += $aiMakerProfile

        # AI workbench profile (Red tier only)
        if ($Tier -eq "Red") {
            $aiWorkbenchProfile = [PSCustomObject]@{
                guid                    = $aiWorkbenchGuid
                name                    = "AI workbench"
                commandline             = "pwsh.exe -NoProfile -Command `"gh copilot -- --agent ai-workbench`""
                tabColor                = "#CE1126"
                tabTitle                = "AI workbench"
                suppressApplicationTitle = $true
                startingDirectory       = $WorkspacePath
                hidden                  = $true
            }
            $settings.profiles.list += $aiWorkbenchProfile
        }

        if (-not $WhatIf) {
            $settings | ConvertTo-Json -Depth 10 | Set-Content $wtSettings -Force
        }
        $profileMsg = if ($Tier -eq "Red") { "AI maker (yellow) + AI workbench (red)" } else { "AI maker (yellow)" }
        Write-OK "$profileMsg profile(s) added"
    } catch {
        Write-Warn "Could not update Windows Terminal settings: $_"
    }
} else {
    Write-Warn "Windows Terminal settings not found — open WT once, then re-run"
}

# ─── Desktop Shortcut: "AI Workspace CLI" ────────────────────
Write-Host ""
if (-not $SkipGitHub) {
Write-Step "Creating desktop shortcut"

$desktopPath = [Environment]::GetFolderPath("Desktop")
$shortcutName = "AI Workspace CLI"
$shortcutPath = Join-Path $desktopPath "$shortcutName.lnk"

if ($WhatIf) {
    Write-Host "  Would create/update desktop shortcut" -ForegroundColor Yellow
} else {
    try {
        # Copy launcher assets to a stable local path so shortcut target never breaks
        $launcherDir = Join-Path $env:LOCALAPPDATA "new-user-pc-setup\launcher"
        if (-not (Test-Path $launcherDir)) { New-Item -ItemType Directory -Path $launcherDir -Force | Out-Null }

        $srcStart = Join-Path $PSScriptRoot "start.ps1"
        $srcIcon  = Join-Path $PSScriptRoot "github-copilot.ico"
        $dstStart = Join-Path $launcherDir "start.ps1"
        $dstIcon  = Join-Path $launcherDir "github-copilot.ico"

        Copy-Item -Path $srcStart -Destination $dstStart -Force
        if (Test-Path $srcIcon) { Copy-Item -Path $srcIcon -Destination $dstIcon -Force }

        # Resolve full path to pwsh so shortcut works regardless of PATH state
        $pwshExe = (Get-Command pwsh -ErrorAction SilentlyContinue).Source
        if (-not $pwshExe) { $pwshExe = "$env:ProgramFiles\PowerShell\7\pwsh.exe" }
        if (-not (Test-Path $pwshExe)) { $pwshExe = "pwsh.exe" }

        $isUpdate = Test-Path $shortcutPath
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $pwshExe
        $shortcut.Arguments = "-WindowStyle Hidden -File `"$dstStart`" -WorkspacePath `"$WorkspacePath`" -Tier $Tier"
        $shortcut.WorkingDirectory = $WorkspacePath
        $shortcut.Description = "Open AI agents in Windows Terminal"
        if (Test-Path $dstIcon) { $shortcut.IconLocation = "$dstIcon,0" }
        $shortcut.Save()

        $action = if ($isUpdate) { "updated" } else { "created" }
        Write-OK "Desktop shortcut $action`: $shortcutName"
    } catch {
        Write-Warn "Could not create desktop shortcut: $_"
    }
}
} # end if Red tier desktop shortcut

# ═══════════════════════════════════════════════════════════════
# MILESTONE 6 COMPLETE
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "  ✓ Milestone 6 complete: Machine Config" -ForegroundColor Green
Write-Host "  ────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host ""

# ═══════════════════════════════════════════════════════════════
# FINAL SUMMARY
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║       Setup Complete!                    ║" -ForegroundColor Cyan
Write-Host "  ╚══════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "  What was set up:" -ForegroundColor White
if ($SkipGitHub) {
    Write-Host "    ✓ Apps installed (GitHub workspace skipped)" -ForegroundColor Green
    Write-Host "    ✓ Shell configured (Oh My Posh + Copilot aliases)" -ForegroundColor Green
    Write-Host "    ✓ Windows Terminal configured" -ForegroundColor Green
    Write-Host "    ⚠ Workspace skipped — re-run without -SkipGitHub when you have GitHub access" -ForegroundColor Yellow
} else {
    $skillCount = if ($Tier -eq "Blue") { "11" } else { "22" }
    Write-Host "    ✓ GitHub authenticated as $ghUser" -ForegroundColor Green
    Write-Host "    ✓ Apps installed" -ForegroundColor Green
    Write-Host "    ✓ Workspace at $WorkspacePath ($skillCount skills)" -ForegroundColor Green
    Write-Host "    ✓ Shell configured (Oh My Posh + Copilot aliases)" -ForegroundColor Green
    Write-Host "    ✓ Windows Terminal configured" -ForegroundColor Green
}
Write-Host ""
Write-Host "  What to do next:" -ForegroundColor White
Write-Host "    1. Close this window and open Windows Terminal" -ForegroundColor Gray
if (-not $SkipGitHub) {
    Write-Host "    2. Your workspace is ready at: $WorkspacePath" -ForegroundColor Gray
}
Write-Host ""

# Launch GitHub Copilot App
$copilotExe = Resolve-Exe -Name "github" -KnownPaths @("$env:LOCALAPPDATA\Programs\GitHub Copilot\github.exe")
if ($copilotExe -and -not $WhatIf) {
    Write-Host "  Launching GitHub Copilot..." -ForegroundColor Gray
    Start-Process $copilotExe
}
Write-Host ""

if ($script:Failures.Count -gt 0) {
    Write-Host "  Issues to resolve:" -ForegroundColor Yellow
    foreach ($f in $script:Failures) { Write-Host "    ⚠ $f" -ForegroundColor Yellow }
    Write-Host ""
}

# Save final log
$logFile = Save-Log
Write-Host "  Log saved: $logFile" -ForegroundColor DarkGray
Write-Host ""
Read-Host "  Press Enter to exit"

