<#
.SYNOPSIS
    AI Workspace CLI — Launches Windows Terminal with AI maker (+ AI workbench for Red).
.DESCRIPTION
    Opens Windows Terminal with agent tabs pointing at the AI workspace.
    Called by the "AI Workspace CLI" desktop shortcut.
#>

param(
    [string]$WorkspacePath = "C:\GitHub\ai-workspace",
    [string]$Tier = "Blue"
)

# Resolve wt.exe
$wt = Get-Command wt.exe -ErrorAction SilentlyContinue
if (-not $wt) {
    $wt = "$env:LOCALAPPDATA\Microsoft\WindowsApps\wt.exe"
    if (-not (Test-Path $wt)) {
        Write-Host "Windows Terminal not found. Install it from the Microsoft Store." -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }
}

# Launch with tier-appropriate tabs (pattern from nancie-setup)
$wtArgs = "new-tab --title `"AI maker`" --profile `"AI maker`" --startingDirectory `"$WorkspacePath`""
if ($Tier -eq "Red") {
    $wtArgs += " ; new-tab --title `"AI workbench`" --profile `"AI workbench`" --startingDirectory `"$WorkspacePath`""
}
Start-Process "wt.exe" -ArgumentList $wtArgs
