<#
.SYNOPSIS
    AI Workspace CLI — Launches Windows Terminal with AI maker (+ AI workbench for Red).
.DESCRIPTION
    Opens Windows Terminal with agent tabs pointing at the AI workspace.
    Called by the "AI Workspace CLI" desktop shortcut.
#>

param(
    [string]$WorkspacePath = "C:\GitHub\ai-workspace",
    [string]$Tier = "Blue"
)

# Resolve wt.exe
$wtExe = (Get-Command wt.exe -ErrorAction SilentlyContinue).Source
if (-not $wtExe) {
    $wtExe = "$env:LOCALAPPDATA\Microsoft\WindowsApps\wt.exe"
    if (-not (Test-Path $wtExe)) {
        Write-Host "Windows Terminal not found. Install it from the Microsoft Store." -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }
}

# Launch directly with gh copilot commands, without depending on pre-existing WT profile names.
$wtArgs = "new-tab --title `"AI maker`" --tabColor `"#FFCB05`" -d `"$WorkspacePath`" pwsh.exe -NoProfile -Command `"gh copilot`""
if ($Tier -eq "Red") {
    $wtArgs += " ; new-tab --title `"AI workbench`" --tabColor `"#CE1126`" -d `"$WorkspacePath`" pwsh.exe -NoProfile -Command `"gh copilot -- --agent ai-workbench`""
}
Start-Process $wtExe -ArgumentList $wtArgs
