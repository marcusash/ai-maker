@echo off
setlocal EnableExtensions EnableDelayedExpansion

:: ═══════════════════════════════════════════════════════════════
:: new-user-pc-setup v1.0 — Universal entry point
:: Double-click this file or run from any terminal.
:: ═══════════════════════════════════════════════════════════════

echo.
echo   new-user-pc-setup v1.0
echo   ----------------------
echo.

:: ─── Step 1: Find or install PowerShell 7 ───────────────────

set "PWSH="
where pwsh >nul 2>nul && set "PWSH=pwsh" && goto :found_pwsh
if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" set "PWSH=%ProgramFiles%\PowerShell\7\pwsh.exe" && goto :found_pwsh
if exist "%LOCALAPPDATA%\Microsoft\PowerShell\pwsh.exe" set "PWSH=%LOCALAPPDATA%\Microsoft\PowerShell\pwsh.exe" && goto :found_pwsh

echo   PowerShell 7 not found. Installing...
echo.
winget install Microsoft.PowerShell --source winget --accept-source-agreements --accept-package-agreements --scope user
echo.

:: Re-check after install (PATH won't update in this session)
where pwsh >nul 2>nul && set "PWSH=pwsh" && goto :found_pwsh
if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" set "PWSH=%ProgramFiles%\PowerShell\7\pwsh.exe" && goto :found_pwsh
if exist "%LOCALAPPDATA%\Microsoft\PowerShell\pwsh.exe" set "PWSH=%LOCALAPPDATA%\Microsoft\PowerShell\pwsh.exe" && goto :found_pwsh

echo.
echo   ERROR: Could not find PowerShell 7 after install.
echo   Try closing this window, opening a new terminal, and running setup.bat again.
echo.
pause
exit /b 1

:found_pwsh
echo   [OK] PowerShell 7: !PWSH!
echo.

:: ─── Step 2: Launch install.ps1 ─────────────────────────────

:: Determine script location (works from ZIP extract or cloned repo)
set "SCRIPT_DIR=%~dp0"
if exist "%SCRIPT_DIR%install.ps1" (
    "!PWSH!" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install.ps1" -Tier Blue
) else (
    echo   ERROR: install.ps1 not found in %SCRIPT_DIR%
    echo   Make sure setup.bat and install.ps1 are in the same folder.
    echo.
    pause
    exit /b 1
)

pause

