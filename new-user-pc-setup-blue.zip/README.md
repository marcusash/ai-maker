# New User PC Setup

Set up your PC for AI-powered work in one step. Double-click and go.

## What You Need

- Windows 11 PC
- Internet connection
- A GitHub account (all Microsoft employees have one)

## How to Run

1. Open this folder in File Explorer
2. Double-click **setup-blue.bat** (or **setup-red.bat** for Red Pill)
3. Follow the prompts — the whole thing takes about 5 minutes

That's it. When it's done, close the window and open **Windows Terminal** to start working.

## What Gets Installed

| App | What it's for |
|-----|---------------|
| Git | Saves your work history |
| PowerShell 7 | Modern terminal |
| GitHub CLI | Connects your PC to GitHub |
| GitHub Copilot | AI assistant (main app) |
| VS Code | Code editor with Copilot built in |
| Node.js | Powers AI agent skills |
| Oh My Posh | Makes your terminal look nice |
| Windows Terminal | Better terminal app |
| Agency | Runs AI agents locally |

## What Gets Configured

- **Your AI workspace** — downloaded from (or created on) GitHub at `C:\GitHub\ai-workspace`
- **Terminal theme** — colorful prompt that shows your current folder and status
- **Copilot aliases** — type `ghcs` for AI suggestions, `ghce` for explanations
- **Desktop shortcut** — "AI Workspace" opens your workspace in one click

## Options

| Flag | What it does |
|------|--------------|
| `-SkipGitHub` | Skip GitHub auth + workspace (for day-1 hires without accounts yet) |
| `-WorkspacePath "D:\my-workspace"` | Use a different folder |
| `-WhatIf` | Preview what would happen without changing anything |

## Troubleshooting

**"Authentication failed"** — Make sure you're signed into GitHub in your browser first, then retry.

**An app failed to install** — The error will show the manual install command. Run it separately and then re-run setup-blue.bat (or setup-red.bat).

**Profile error on new tab** — Run `.\fix-profile.ps1` in this folder to clean up.

## Development

Built in milestones, tested on real machines before each ships.

| # | Milestone | Status |
|---|-----------|--------|
| M1 | Bootstrap & Auth | ✅ Done |
| M2 | Auto-Detect & Branching | ✅ Done |
| M3 | App Installation | ✅ Done |
| M4 | Fresh Path (scaffold) | ✅ Done |
| M5 | Restore Path (clone) | ✅ Done |
| M6 | Machine Config | ✅ Done |
| M7 | Summary + Docs + Polish | ✅ Done |
