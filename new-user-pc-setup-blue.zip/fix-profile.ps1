# fix-profile.ps1 — Cleans up bloated PowerShell profiles from old nancie-setup
$docs = [Environment]::GetFolderPath("MyDocuments")
$block = @'
# === PC-SETUP BEGIN ===
function ghcs { gh copilot suggest @args }
function ghce { gh copilot explain @args }
$_ompTheme = "powerlevel10k_rainbow"
$_ompExe = Get-Command oh-my-posh -ErrorAction SilentlyContinue
if ($_ompExe) {
    $_ompThemesPath = & oh-my-posh get shell-themes-path 2>$null
    if (-not $_ompThemesPath) { $_ompThemesPath = $env:POSH_THEMES_PATH }
    if ($_ompThemesPath -and (Test-Path "$_ompThemesPath\$_ompTheme.omp.json")) {
        oh-my-posh init pwsh --config "$_ompThemesPath\$_ompTheme.omp.json" | Invoke-Expression
    }
}
# === PC-SETUP END ===
'@
$block | Set-Content "$docs\PowerShell\Microsoft.PowerShell_profile.ps1" -Force
$block | Set-Content "$docs\WindowsPowerShell\Microsoft.PowerShell_profile.ps1" -Force
Write-Host "Both profiles fixed! Open a new tab to see the change." -ForegroundColor Green
